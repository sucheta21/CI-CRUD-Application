<?php 
class Usermodel extends CI_model{
	function create($formArray){
		$this->db->insert('student',$formArray);
	}

	function show(){
		return $users=$this->db->get('student')->result_array();
	}

	function getuser($userId){
		$this->db->where('id',$userId);
		return $user=$this->db->get('student')->row_array();
	}
	function updateuser($userId,$formArray){
			$this->db->where('id',$userId);
		$this->db->update('student',$formArray);
	}
	function deleteuser($userId){
			$this->db->where('id',$userId);
		$this->db->delete('student');
	}
}
?>
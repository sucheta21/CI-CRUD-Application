<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap.min.css'; ?>">
</head>
<body>
	<div class="container">Registration </div>
	<hr>

	<div class="container">
		
		<form name="createform" action="<?php echo base_url().'index.php/users/create'; ?>" method="post">
		<div class="row">
			
			<div class="col-md-6">
				<div class="form-group">
					<label>Name</label>
				<input type="text" name="name" value="<?php echo set_value('name'); ?>" placeholder="Enter Name" class="form-control">
				<?php echo form_error('name');?>
				</div>
				
			
			
				<div class="form-group">
				<label>Email</label>
				<input type="email" name="email" value="<?php echo set_value('email'); ?>" placeholder="Enter Email" class="form-control">
				<?php echo form_error('email')?>
			</div>

			<div class="form-group">
				<button class="btn btn-primary">Create</button>
				<a class="btn btn-secondary" href="<?php echo base_url().'index.php/users/index' ?>">Cancel</a>
			</div>
		</div>
	
			
		</div>
		</form>
	</div>

</body>
</html>
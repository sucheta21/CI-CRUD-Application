<!DOCTYPE html>
<html>
<head>
	<title>Update User</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap.min.css'; ?>">
</head>
<body>
	<div class="container">Edit User </div>
	<hr>

	<div class="container">
		<form name="createform" action="<?php echo base_url().'index.php/users/edit/'.$user['id']; ?>" method="post">
		<div class="row">
			
			<div class="col-md-6">
				<div class="form-group">
					<label>Name</label>
				<input type="text" name="name" value="<?php echo set_value('name',$user['name']); ?>" placeholder="Enter Name" class="form-control">
				<?php echo form_error('name');?>
				</div>
				
			
			
				<div class="form-group">
				<label>Email</label>
				<input type="email" name="email" value="<?php echo set_value('email',$user['email']); ?>" placeholder="Enter Email" class="form-control">
				<?php echo form_error('email')?>
			</div>

			<div class="form-group">
				<button class="btn btn-primary">Update</button>
				<a class="btn btn-secondary" href="<?php echo base_url().'index.php/users/index' ?>">Cancel</a>
			</div>
		</div>
	
			
		</div>
		</form>
	</div>

</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title>View Student</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap.min.css'; ?>">
</head>
<body>
	
	<hr>

	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<?php
					$sucess=$this->session->userdata('sucess');
					if($sucess!=""){?>
						<div class="alert alert-success"><?php echo $sucess;?></div>
					<?php }

				 ?>
				 <?php
					$failure=$this->session->userdata('failure');
					if($failure!=""){?>
						<div class="alert alert-success"><?php echo $failure;?></div>
					<?php }

				 ?>
			</div>
		</div>

		<div class="col-md-8">
		<div class="row">
			
		<div class="col-md-6">View Student</div>
		<div class="col-md-6 text-right"><a href="<?php echo base_url().'index.php/users/create/'?>" class="btn btn-primary">Create</a></div>
	</div>
</div>
		<hr>
		
		<div class="row">
			
			<div class="col-md-8">
				<table class="table table-striped">
					<tr>
						<td>Id</td>
						<td>Name</td>
						<td>Email</td>
						<td>Edit</td>
						<td>Delete</td>
					</tr>
					<?php if(!empty($users)){foreach ($users as $users) {?>
						<tr>
						<td><?php echo $users['id']?></td>
						<td><?php echo $users['name']?></td>
						<td><?php echo $users['email']?></td>
						<td><a href="<?php echo base_url().'index.php/users/edit/'.$users['id'] ?>" class="btn btn-primary">Edit</a></td>
						<td><a href="<?php echo base_url().'index.php/users/delete/'.$users['id'] ?>" class="btn btn-danger">Delete</a></td>
					</tr>
				<?php }} else{?>
					<tr><td colspan="5">No records found!</td></tr>
				<?php }?>
				</table>
				
			</div>
			
		</div>
		
	</div>

</body>
</html>